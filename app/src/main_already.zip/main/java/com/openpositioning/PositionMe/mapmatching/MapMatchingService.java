package com.openpositioning.PositionMe.mapmatching;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.gms.maps.model.LatLng;
import com.openpositioning.PositionMe.data.remote.FloorplanApiClient;

/**
 * 3.2 Map Matching 的核心服务类。
 *
 * 当前这一版重点修复 replay 楼层切换中的一个关键问题：
 * 当候选楼层已经变化时，不能直接用“目标楼层”的 stairs/lift 几何
 * 去判断当前这一帧是否允许换层，否则会出现：
 * - 当前楼层明明没有楼梯/电梯
 * - 但因为目标楼层同一 XY 附近有楼梯/电梯
 * - 楼层切换被错误放行
 *
 * 因此：
 * 1. 墙体检查默认基于 source floor（上一已确认楼层）
 * 2. 楼层切换是否合法，也先看 source floor 的 connector
 */
public class MapMatchingService {
    // 水平位移较小时，更像 lift
    private static final double MAX_LIFT_HORIZONTAL_DISPLACEMENT_METERS = 1.5;
    // 位移太小时，不做穿墙检测，避免传感器抖动带来误判
    private static final double MIN_DISPLACEMENT_FOR_WALL_CHECK_METERS = 0.3;

    @NonNull
    public MapMatchingResult match(@NonNull MapMatchingInput input) {
        CandidatePose currentPose = input.getCurrentCandidatePose();
        CandidatePose previousPose = input.getPreviousPose();

        boolean floorTransitionAttempt = previousPose != null
                && currentPose.getFloor() != previousPose.getFloor();
        boolean floorChangeAllowed = isFloorChangeAllowed(input);

        FloorplanApiClient.FloorShapes connectorFloorShapes = chooseConnectorFloorShapes(input, floorTransitionAttempt);
        FloorplanApiClient.FloorShapes wallCheckFloorShapes = chooseWallCheckFloorShapes(input, floorTransitionAttempt);

        LatLng candidateLatLng = currentPose.getLatLng();
        LatLng correctedLatLng = candidateLatLng;
        int correctedFloor = currentPose.getFloor();

        boolean nearStairs = false;
        boolean nearLift = false;
        boolean crossedWall = false;
        boolean invalidFloorChange = false;

        CorrectionType correctionType = CorrectionType.NONE;
        String debugReason = "Candidate pose accepted.";
        boolean validPosition = true;

        if (connectorFloorShapes != null) {
            nearStairs = MapGeometryUtils.isNearStairs(candidateLatLng, connectorFloorShapes);
            nearLift = MapGeometryUtils.isNearLift(candidateLatLng, connectorFloorShapes);
        }

        MotionDelta motionDelta = input.getMotionDelta();
        String transitionDescription = describeVerticalTransition(nearStairs, nearLift, motionDelta);
        if (input.getVerticalHint() != null && input.getVerticalHint().isHeightChanged()) {
            debugReason = "Height changed; " + transitionDescription + ".";
        } else {
            debugReason = "Candidate pose accepted; " + transitionDescription + ".";
        }

        // 没有任何可用楼层地图时，不做墙体约束。
        if (wallCheckFloorShapes == null) {
            return new MapMatchingResult(
                    true,
                    false,
                    nearStairs,
                    nearLift,
                    floorChangeAllowed,
                    candidateLatLng,
                    currentPose.getFloor(),
                    CorrectionType.NONE,
                    "No usable wall map. Pass through candidate pose."
            );
        }

        // 穿墙检测：楼层切换尝试时优先看 source floor，避免被目标层几何误导。
        if (previousPose != null && previousPose.getLatLng() != null) {
            boolean shouldCheckWall = true;
            if (motionDelta != null) {
                shouldCheckWall = motionDelta.getStepDistance() >= MIN_DISPLACEMENT_FOR_WALL_CHECK_METERS;
            }

            if (shouldCheckWall) {
                crossedWall = MapGeometryUtils.crossesWall(
                        previousPose.getLatLng(),
                        candidateLatLng,
                        wallCheckFloorShapes
                );

                if (crossedWall) {
                    LatLng latOnlyPoint = new LatLng(candidateLatLng.latitude, previousPose.getLatLng().longitude);
                    LatLng lngOnlyPoint = new LatLng(previousPose.getLatLng().latitude, candidateLatLng.longitude);

                    boolean canMoveLat = !MapGeometryUtils.crossesWall(previousPose.getLatLng(), latOnlyPoint, wallCheckFloorShapes);
                    boolean canMoveLng = !MapGeometryUtils.crossesWall(previousPose.getLatLng(), lngOnlyPoint, wallCheckFloorShapes);

                    if (canMoveLat && !canMoveLng) {
                        correctedLatLng = latOnlyPoint;
                        correctionType = CorrectionType.THROUGH_WALL;
                        debugReason = "Crossed wall. Sliding along Latitude (N/S).";
                        validPosition = true;
                    } else if (!canMoveLat && canMoveLng) {
                        correctedLatLng = lngOnlyPoint;
                        correctionType = CorrectionType.THROUGH_WALL;
                        debugReason = "Crossed wall. Sliding along Longitude (E/W).";
                        validPosition = true;
                    } else {
                        correctedLatLng = previousPose.getLatLng();
                        if (!floorChangeAllowed) {
                            correctedFloor = previousPose.getFloor();
                        }
                        correctionType = CorrectionType.THROUGH_WALL;
                        debugReason = "Crossed wall. Stuck in corner, reverted to previous XY pose.";
                        validPosition = false;
                    }
                }
            } else {
                debugReason = "Step distance too small for wall check. Candidate pose accepted.";
            }
        }

        if (floorTransitionAttempt && !floorChangeAllowed) {
            invalidFloorChange = true;
            correctedFloor = previousPose.getFloor();
            if (correctionType == CorrectionType.NONE) {
                correctionType = CorrectionType.INVALID_FLOOR_CHANGE;
                debugReason = "Floor change rejected: source floor is not near valid stairs/lift or height change is invalid.";
            }
            validPosition = false;
        }

        return new MapMatchingResult(
                validPosition,
                crossedWall,
                nearStairs,
                nearLift,
                floorChangeAllowed,
                correctedLatLng,
                correctedFloor,
                correctionType,
                debugReason
        );
    }

    public boolean isFloorChangeAllowed(@NonNull MapMatchingInput input) {
        VerticalTransitionHint verticalHint = input.getVerticalHint();
        CandidatePose previousPose = input.getPreviousPose();
        CandidatePose currentPose = input.getCurrentCandidatePose();

        if (verticalHint == null || !verticalHint.isHeightChanged()) {
            return false;
        }

        if (previousPose == null || currentPose.getFloor() == previousPose.getFloor()) {
            return false;
        }

        FloorplanApiClient.FloorShapes connectorFloorShapes = chooseConnectorFloorShapes(input, true);
        if (connectorFloorShapes == null) {
            // 没有地图时维持旧版宽松策略，不阻断已有逻辑。
            return true;
        }

        LatLng currentPoint = currentPose.getLatLng();
        boolean nearStairs = MapGeometryUtils.isNearStairs(currentPoint, connectorFloorShapes);
        boolean nearLift = MapGeometryUtils.isNearLift(currentPoint, connectorFloorShapes);

        if (!nearStairs && !nearLift) {
            return false;
        }

        MotionDelta motionDelta = input.getMotionDelta();
        if (motionDelta == null) {
            return true;
        }

        double stepDistance = motionDelta.getStepDistance();
        boolean likelyLiftMotion = stepDistance <= MAX_LIFT_HORIZONTAL_DISPLACEMENT_METERS;

        if (nearLift && !nearStairs) {
            return likelyLiftMotion;
        }
        if (nearStairs && !nearLift) {
            return !likelyLiftMotion;
        }
        return true;
    }

    @Nullable
    private FloorplanApiClient.FloorShapes chooseConnectorFloorShapes(@NonNull MapMatchingInput input,
                                                                      boolean floorTransitionAttempt) {
        if (floorTransitionAttempt && input.getSourceFloorShapes() != null) {
            return input.getSourceFloorShapes();
        }
        if (input.getActiveFloorShapes() != null) {
            return input.getActiveFloorShapes();
        }
        return input.getSourceFloorShapes();
    }

    @Nullable
    private FloorplanApiClient.FloorShapes chooseWallCheckFloorShapes(@NonNull MapMatchingInput input,
                                                                      boolean floorTransitionAttempt) {
        if (floorTransitionAttempt && input.getSourceFloorShapes() != null) {
            return input.getSourceFloorShapes();
        }
        if (input.getActiveFloorShapes() != null) {
            return input.getActiveFloorShapes();
        }
        return input.getSourceFloorShapes();
    }

    private String describeVerticalTransition(boolean nearStairs,
                                              boolean nearLift,
                                              @Nullable MotionDelta motionDelta) {
        if (!nearStairs && !nearLift) {
            return "not near stairs or lift";
        }

        if (motionDelta == null) {
            if (nearStairs && nearLift) return "near both stairs and lift";
            if (nearStairs) return "near stairs";
            return "near lift";
        }

        double stepDistance = motionDelta.getStepDistance();
        boolean likelyLiftMotion = stepDistance <= MAX_LIFT_HORIZONTAL_DISPLACEMENT_METERS;

        if (nearLift && !nearStairs) {
            return likelyLiftMotion
                    ? "likely lift transition"
                    : "lift nearby but horizontal movement looks too large";
        }

        if (nearStairs && !nearLift) {
            return likelyLiftMotion
                    ? "stairs nearby but horizontal movement looks too small"
                    : "likely stairs transition";
        }

        return likelyLiftMotion
                ? "near both stairs and lift, motion slightly favors lift"
                : "near both stairs and lift, motion slightly favors stairs";
    }
}
